insert into ampip.datosDeUsuario (id, key_corp, cargo, telefonoOfficina, celular, direccionDeOfficina, cumpleanios, compartirDatos, habilitar, idAmpip)
values  (1, 3, 'Administrator', '1', '1', '1', '1', 0, 1, 1),
        (68, 1, 'privado', '5533147171', '5527749267', 'ZUMPANGO', '1999-04-06', 0, 1, 42);