insert into ampip.role (id, name, description, date_created)
values  (1, 'Administrator', 'Administrator', '2021-04-05 14:05:59'),
        (2, 'privado', 'desarollador privad', '2021-04-06 12:55:41'),
        (3, 'Gob Est', 'Gobierno Estatal', '2021-04-06 12:56:38'),
        (4, 'idefinido', 'Usuario en espera', null);