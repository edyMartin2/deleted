insert into ampip.parques_usuarios (id, persona, id_parque, permiso)
values  (1, 42, 1, 'solo lectura');