insert into ampip.nave (id, name, parque_id)
values  (4, 'nueva', 1),
        (5, 'nueva nave', 1);