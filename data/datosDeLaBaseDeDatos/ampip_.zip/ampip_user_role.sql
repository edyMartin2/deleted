insert into ampip.user_role (id, user_id, role_id)
values  (1, 1, 1),
        (2, 42, 4);